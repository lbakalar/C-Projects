﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentSystem
{
    public partial class AssignmentsForm : Form
    {
        public AssignmentsForm()
        {
            InitializeComponent();
        }        

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AssignmentsForm_Load(object sender, EventArgs e)
        {
            foreach (var item in MainForm.studentList)
            {
                if (item is DormStudent)
                {
                    DormStudent ds = new DormStudent();
                    ds = (DormStudent)item;
                    item.ToString();
                    lstBoxAssignment.Items.Add(item);
                }
                else
                {
                    Student s = new Student();
                    s = (Student)item;
                    s.ToString();
                    lstBoxAssignment.Items.Add(item);
                }
            }

            Student st = MainForm.studentList[0];
            lstBoxAssignment.SelectedIndex = 0;
            if (st.ClassAssignments != null)
            {
                for (int i = 0; i < st.ClassAssignments.Count(); i++)
                {
                    List<Assignment> l = st.ClassAssignments;
                    dgvAssignments.Rows.Add();
                    dgvAssignments.Rows[i].Cells[0].Value = l[i].name;
                    dgvAssignments.Rows[i].Cells[1].Value = l[i].ptsEarned;
                    dgvAssignments.Rows[i].Cells[2].Value = l[i].ptsPoss;
                    i++;
                }
            }
            
        }
        
        private void lstBoxAssignment_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i = 0;
            dgvAssignments.Rows.Clear();

            List<Assignment> tempList = MainForm.studentList[lstBoxAssignment.SelectedIndex].ClassAssignments;

            if (MainForm.studentList[lstBoxAssignment.SelectedIndex].ClassAssignments != null)
            {
                foreach (var item in MainForm.studentList[lstBoxAssignment.SelectedIndex].ClassAssignments)
                {
                    dgvAssignments.Rows.Add();
                    dgvAssignments.Rows[i].Cells[0].Value = item.name;
                    dgvAssignments.Rows[i].Cells[1].Value = item.ptsEarned;
                    dgvAssignments.Rows[i].Cells[2].Value = item.ptsPoss;
                    i++;
                } 
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            MainForm.studentList[lstBoxAssignment.SelectedIndex].ClassAssignments = new List<Assignment>();

            foreach (DataGridViewRow dr in dgvAssignments.Rows)
            {
                if (dr.Cells[0].Value != null)  
                {
                    string t = dr.Cells[0].Value.ToString();
                    int n = Convert.ToInt32(dr.Cells[1].Value);
                    double p = Convert.ToDouble(dr.Cells[2].Value);
                    Assignment a = new Assignment(t, n, p);

                    MainForm.studentList[lstBoxAssignment.SelectedIndex].ClassAssignments.Add(a);
                }

            }
        }
    }
}
