﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentSystem
{
    [Serializable]
    public class DormStudent : Student
    {
        public string dormLoc;
        public string mealPlan;

        public string DormLocation
        {
            get
            {
                return dormLoc;
            }
            set
            {
                if (String.IsNullOrEmpty(value))
                {
                    dormLoc = "Unknown";
                }
                else
                {
                    dormLoc = value;
                }
            }
        }

        public string MealPlanType
        {
            get
            {
                return mealPlan;
            }
            set
            {
                if (String.IsNullOrEmpty(value))
                {
                    mealPlan = "Unknown";
                }
                else
                {
                    mealPlan = value;
                }
            }
        }

        //default constructor 
        public DormStudent() : base()
        {
            dormLoc = "Unknown";
            mealPlan = "Unknown";
        }

        //overloaded constructor 
        public DormStudent(int id, string nm, string dl, string mp) : base(id, nm)
        {
            dormLoc = dl;
            mealPlan = mp;
        }

        public DormStudent(int id, string nm, List<Assignment> aList, string dl, string mp) : base(id, nm, aList)
        {
            dormLoc = dl;
            mealPlan = mp;
        }

        public override string ToString()
        {
            return base.ToString() + "                          " + dormLoc + "                             " + mealPlan;
        }
    //bracket ends class
    }
//bracket ends namespace
}
