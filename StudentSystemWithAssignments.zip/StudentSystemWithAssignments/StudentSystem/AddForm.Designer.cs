﻿namespace StudentSystem
{
    partial class AddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.grpBoxDorm = new System.Windows.Forms.GroupBox();
            this.rBtnMahaska = new System.Windows.Forms.RadioButton();
            this.rBtnApp = new System.Windows.Forms.RadioButton();
            this.rBtnWapello = new System.Windows.Forms.RadioButton();
            this.rBtnTrustee = new System.Windows.Forms.RadioButton();
            this.rBtnOak = new System.Windows.Forms.RadioButton();
            this.grpBoxMeal = new System.Windows.Forms.GroupBox();
            this.rBtnHigh = new System.Windows.Forms.RadioButton();
            this.rBtnMed = new System.Windows.Forms.RadioButton();
            this.rBtnBasic = new System.Windows.Forms.RadioButton();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.rBtnDormStud = new System.Windows.Forms.RadioButton();
            this.rBtnNonDorm = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.grpBoxDorm.SuspendLayout();
            this.grpBoxMeal.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(235, 112);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(120, 20);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Student Name: ";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(239, 135);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 26);
            this.txtName.TabIndex = 3;
            // 
            // grpBoxDorm
            // 
            this.grpBoxDorm.Controls.Add(this.rBtnMahaska);
            this.grpBoxDorm.Controls.Add(this.rBtnApp);
            this.grpBoxDorm.Controls.Add(this.rBtnWapello);
            this.grpBoxDorm.Controls.Add(this.rBtnTrustee);
            this.grpBoxDorm.Controls.Add(this.rBtnOak);
            this.grpBoxDorm.Location = new System.Drawing.Point(24, 38);
            this.grpBoxDorm.Name = "grpBoxDorm";
            this.grpBoxDorm.Size = new System.Drawing.Size(167, 186);
            this.grpBoxDorm.TabIndex = 8;
            this.grpBoxDorm.TabStop = false;
            this.grpBoxDorm.Text = "Dorm Location: ";
            // 
            // rBtnMahaska
            // 
            this.rBtnMahaska.AutoSize = true;
            this.rBtnMahaska.Location = new System.Drawing.Point(22, 148);
            this.rBtnMahaska.Name = "rBtnMahaska";
            this.rBtnMahaska.Size = new System.Drawing.Size(99, 24);
            this.rBtnMahaska.TabIndex = 4;
            this.rBtnMahaska.TabStop = true;
            this.rBtnMahaska.Text = "Mahaska";
            this.rBtnMahaska.UseVisualStyleBackColor = true;
            // 
            // rBtnApp
            // 
            this.rBtnApp.AutoSize = true;
            this.rBtnApp.Location = new System.Drawing.Point(22, 118);
            this.rBtnApp.Name = "rBtnApp";
            this.rBtnApp.Size = new System.Drawing.Size(116, 24);
            this.rBtnApp.TabIndex = 3;
            this.rBtnApp.TabStop = true;
            this.rBtnApp.Text = "Appanoose";
            this.rBtnApp.UseVisualStyleBackColor = true;
            // 
            // rBtnWapello
            // 
            this.rBtnWapello.AutoSize = true;
            this.rBtnWapello.Location = new System.Drawing.Point(22, 88);
            this.rBtnWapello.Name = "rBtnWapello";
            this.rBtnWapello.Size = new System.Drawing.Size(91, 24);
            this.rBtnWapello.TabIndex = 2;
            this.rBtnWapello.TabStop = true;
            this.rBtnWapello.Text = "Wapello";
            this.rBtnWapello.UseVisualStyleBackColor = true;
            // 
            // rBtnTrustee
            // 
            this.rBtnTrustee.AutoSize = true;
            this.rBtnTrustee.Location = new System.Drawing.Point(22, 58);
            this.rBtnTrustee.Name = "rBtnTrustee";
            this.rBtnTrustee.Size = new System.Drawing.Size(88, 24);
            this.rBtnTrustee.TabIndex = 1;
            this.rBtnTrustee.TabStop = true;
            this.rBtnTrustee.Text = "Trustee";
            this.rBtnTrustee.UseVisualStyleBackColor = true;
            // 
            // rBtnOak
            // 
            this.rBtnOak.AutoSize = true;
            this.rBtnOak.Location = new System.Drawing.Point(22, 28);
            this.rBtnOak.Name = "rBtnOak";
            this.rBtnOak.Size = new System.Drawing.Size(63, 24);
            this.rBtnOak.TabIndex = 0;
            this.rBtnOak.TabStop = true;
            this.rBtnOak.Text = "Oak";
            this.rBtnOak.UseVisualStyleBackColor = true;
            // 
            // grpBoxMeal
            // 
            this.grpBoxMeal.Controls.Add(this.rBtnHigh);
            this.grpBoxMeal.Controls.Add(this.rBtnMed);
            this.grpBoxMeal.Controls.Add(this.rBtnBasic);
            this.grpBoxMeal.Location = new System.Drawing.Point(388, 26);
            this.grpBoxMeal.Name = "grpBoxMeal";
            this.grpBoxMeal.Size = new System.Drawing.Size(147, 124);
            this.grpBoxMeal.TabIndex = 9;
            this.grpBoxMeal.TabStop = false;
            this.grpBoxMeal.Text = "Meal Plan Type: ";
            // 
            // rBtnHigh
            // 
            this.rBtnHigh.AutoSize = true;
            this.rBtnHigh.Location = new System.Drawing.Point(26, 84);
            this.rBtnHigh.Name = "rBtnHigh";
            this.rBtnHigh.Size = new System.Drawing.Size(67, 24);
            this.rBtnHigh.TabIndex = 2;
            this.rBtnHigh.TabStop = true;
            this.rBtnHigh.Text = "High";
            this.rBtnHigh.UseVisualStyleBackColor = true;
            // 
            // rBtnMed
            // 
            this.rBtnMed.AutoSize = true;
            this.rBtnMed.Location = new System.Drawing.Point(26, 55);
            this.rBtnMed.Name = "rBtnMed";
            this.rBtnMed.Size = new System.Drawing.Size(90, 24);
            this.rBtnMed.TabIndex = 1;
            this.rBtnMed.TabStop = true;
            this.rBtnMed.Text = "Medium";
            this.rBtnMed.UseVisualStyleBackColor = true;
            // 
            // rBtnBasic
            // 
            this.rBtnBasic.AutoSize = true;
            this.rBtnBasic.Location = new System.Drawing.Point(26, 25);
            this.rBtnBasic.Name = "rBtnBasic";
            this.rBtnBasic.Size = new System.Drawing.Size(73, 24);
            this.rBtnBasic.TabIndex = 0;
            this.rBtnBasic.TabStop = true;
            this.rBtnBasic.Text = "Basic";
            this.rBtnBasic.UseVisualStyleBackColor = true;
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(451, 237);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(102, 53);
            this.btnReturn.TabIndex = 7;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(414, 173);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(102, 51);
            this.btnAdd.TabIndex = 6;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // rBtnDormStud
            // 
            this.rBtnDormStud.AutoSize = true;
            this.rBtnDormStud.Location = new System.Drawing.Point(239, 237);
            this.rBtnDormStud.Name = "rBtnDormStud";
            this.rBtnDormStud.Size = new System.Drawing.Size(134, 24);
            this.rBtnDormStud.TabIndex = 5;
            this.rBtnDormStud.TabStop = true;
            this.rBtnDormStud.Text = "Dorm Student";
            this.rBtnDormStud.UseVisualStyleBackColor = true;
            this.rBtnDormStud.CheckedChanged += new System.EventHandler(this.rBtnDormStud_CheckedChanged);
            // 
            // rBtnNonDorm
            // 
            this.rBtnNonDorm.AutoSize = true;
            this.rBtnNonDorm.Location = new System.Drawing.Point(218, 200);
            this.rBtnNonDorm.Name = "rBtnNonDorm";
            this.rBtnNonDorm.Size = new System.Drawing.Size(168, 24);
            this.rBtnNonDorm.TabIndex = 4;
            this.rBtnNonDorm.TabStop = true;
            this.rBtnNonDorm.Text = "Non-Dorm Student";
            this.rBtnNonDorm.UseVisualStyleBackColor = true;
            this.rBtnNonDorm.CheckedChanged += new System.EventHandler(this.rBtnNonDorm_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(235, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student ID: ";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(239, 57);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(100, 26);
            this.txtID.TabIndex = 1;
            this.txtID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtID_KeyPress);
            // 
            // AddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 302);
            this.Controls.Add(this.rBtnNonDorm);
            this.Controls.Add(this.rBtnDormStud);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grpBoxMeal);
            this.Controls.Add(this.grpBoxDorm);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Name = "AddForm";
            this.Text = "Add Student";
            this.Load += new System.EventHandler(this.AddForm_Load);
            this.grpBoxDorm.ResumeLayout(false);
            this.grpBoxDorm.PerformLayout();
            this.grpBoxMeal.ResumeLayout(false);
            this.grpBoxMeal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.GroupBox grpBoxDorm;
        private System.Windows.Forms.RadioButton rBtnMahaska;
        private System.Windows.Forms.RadioButton rBtnApp;
        private System.Windows.Forms.RadioButton rBtnWapello;
        private System.Windows.Forms.RadioButton rBtnTrustee;
        private System.Windows.Forms.RadioButton rBtnOak;
        private System.Windows.Forms.GroupBox grpBoxMeal;
        private System.Windows.Forms.RadioButton rBtnHigh;
        private System.Windows.Forms.RadioButton rBtnMed;
        private System.Windows.Forms.RadioButton rBtnBasic;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.RadioButton rBtnDormStud;
        private System.Windows.Forms.RadioButton rBtnNonDorm;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtID;
    }
}