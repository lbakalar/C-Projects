﻿namespace StudentSystem
{
    partial class DisplayForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstBoxDisplay = new System.Windows.Forms.ListBox();
            this.btnReturn = new System.Windows.Forms.Button();
            this.lblMeal = new System.Windows.Forms.Label();
            this.lblDrm = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstBoxDisplay
            // 
            this.lstBoxDisplay.FormattingEnabled = true;
            this.lstBoxDisplay.ItemHeight = 20;
            this.lstBoxDisplay.Location = new System.Drawing.Point(36, 65);
            this.lstBoxDisplay.Name = "lstBoxDisplay";
            this.lstBoxDisplay.Size = new System.Drawing.Size(615, 264);
            this.lstBoxDisplay.TabIndex = 0;
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(262, 346);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(120, 64);
            this.btnReturn.TabIndex = 1;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // lblMeal
            // 
            this.lblMeal.AutoSize = true;
            this.lblMeal.Location = new System.Drawing.Point(496, 42);
            this.lblMeal.Name = "lblMeal";
            this.lblMeal.Size = new System.Drawing.Size(86, 20);
            this.lblMeal.TabIndex = 13;
            this.lblMeal.Text = "Meal Plan: ";
            // 
            // lblDrm
            // 
            this.lblDrm.AutoSize = true;
            this.lblDrm.Location = new System.Drawing.Point(323, 42);
            this.lblDrm.Name = "lblDrm";
            this.lblDrm.Size = new System.Drawing.Size(121, 20);
            this.lblDrm.TabIndex = 12;
            this.lblDrm.Text = "Dorm Location: ";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(179, 42);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(120, 20);
            this.lblName.TabIndex = 11;
            this.lblName.Text = "Student Name: ";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(55, 42);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(95, 20);
            this.lblID.TabIndex = 10;
            this.lblID.Text = "Student ID: ";
            // 
            // DisplayForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(683, 434);
            this.Controls.Add(this.lblMeal);
            this.Controls.Add(this.lblDrm);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.lstBoxDisplay);
            this.Name = "DisplayForm";
            this.Text = "DisplayForm";
            this.Load += new System.EventHandler(this.DisplayForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstBoxDisplay;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Label lblMeal;
        private System.Windows.Forms.Label lblDrm;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblID;
    }
}