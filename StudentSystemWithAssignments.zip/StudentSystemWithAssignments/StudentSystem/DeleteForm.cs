﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentSystem
{
    public partial class DeleteForm : Form
    {
        public DeleteForm()
        {
            InitializeComponent();
        }

        private void DeleteForm_Load(object sender, EventArgs e)
        {
            foreach (var item in MainForm.studentList)
            {
                if (item is DormStudent)
                {
                    DormStudent ds = new DormStudent();
                    ds = (DormStudent)item;
                    item.ToString();
                    lstBoxDelete.Items.Add(item);
                }
                else
                {
                    Student s = new Student();
                    s = (Student)item;
                    s.ToString();
                    lstBoxDelete.Items.Add(item);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            MainForm.studentList.RemoveAt(lstBoxDelete.SelectedIndex);
            lstBoxDelete.Items.Clear();
            foreach (var item in MainForm.studentList)
            {
                lstBoxDelete.Items.Add(item);
            }            
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }        

        private void lstBoxDelete_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
