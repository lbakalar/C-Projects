﻿namespace StudentSystem
{
    partial class ChangeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReturn = new System.Windows.Forms.Button();
            this.lstBoxChange = new System.Windows.Forms.ListBox();
            this.btnChange = new System.Windows.Forms.Button();
            this.grpBoxDorm = new System.Windows.Forms.GroupBox();
            this.rBtnMahaska = new System.Windows.Forms.RadioButton();
            this.rBtnApp = new System.Windows.Forms.RadioButton();
            this.rBtnWapello = new System.Windows.Forms.RadioButton();
            this.rBtnTrustee = new System.Windows.Forms.RadioButton();
            this.rBtnOak = new System.Windows.Forms.RadioButton();
            this.grpBoxMeal = new System.Windows.Forms.GroupBox();
            this.rBtnHigh = new System.Windows.Forms.RadioButton();
            this.rBtnMed = new System.Windows.Forms.RadioButton();
            this.rBtnBasic = new System.Windows.Forms.RadioButton();
            this.txtID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.rBtnNonDorm = new System.Windows.Forms.RadioButton();
            this.rBtnDormStud = new System.Windows.Forms.RadioButton();
            this.lblMeal = new System.Windows.Forms.Label();
            this.lblDrm = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.grpBoxDorm.SuspendLayout();
            this.grpBoxMeal.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(631, 449);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(120, 64);
            this.btnReturn.TabIndex = 5;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // lstBoxChange
            // 
            this.lstBoxChange.FormattingEnabled = true;
            this.lstBoxChange.ItemHeight = 20;
            this.lstBoxChange.Location = new System.Drawing.Point(57, 39);
            this.lstBoxChange.Name = "lstBoxChange";
            this.lstBoxChange.Size = new System.Drawing.Size(661, 244);
            this.lstBoxChange.TabIndex = 3;
            // 
            // btnChange
            // 
            this.btnChange.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChange.Location = new System.Drawing.Point(470, 449);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(120, 64);
            this.btnChange.TabIndex = 4;
            this.btnChange.Text = "Change";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // grpBoxDorm
            // 
            this.grpBoxDorm.Controls.Add(this.rBtnMahaska);
            this.grpBoxDorm.Controls.Add(this.rBtnApp);
            this.grpBoxDorm.Controls.Add(this.rBtnWapello);
            this.grpBoxDorm.Controls.Add(this.rBtnTrustee);
            this.grpBoxDorm.Controls.Add(this.rBtnOak);
            this.grpBoxDorm.Location = new System.Drawing.Point(35, 310);
            this.grpBoxDorm.Name = "grpBoxDorm";
            this.grpBoxDorm.Size = new System.Drawing.Size(167, 186);
            this.grpBoxDorm.TabIndex = 10;
            this.grpBoxDorm.TabStop = false;
            this.grpBoxDorm.Text = "Dorm Location: ";
            // 
            // rBtnMahaska
            // 
            this.rBtnMahaska.AutoSize = true;
            this.rBtnMahaska.Location = new System.Drawing.Point(22, 148);
            this.rBtnMahaska.Name = "rBtnMahaska";
            this.rBtnMahaska.Size = new System.Drawing.Size(99, 24);
            this.rBtnMahaska.TabIndex = 4;
            this.rBtnMahaska.TabStop = true;
            this.rBtnMahaska.Text = "Mahaska";
            this.rBtnMahaska.UseVisualStyleBackColor = true;
            // 
            // rBtnApp
            // 
            this.rBtnApp.AutoSize = true;
            this.rBtnApp.Location = new System.Drawing.Point(22, 118);
            this.rBtnApp.Name = "rBtnApp";
            this.rBtnApp.Size = new System.Drawing.Size(116, 24);
            this.rBtnApp.TabIndex = 3;
            this.rBtnApp.TabStop = true;
            this.rBtnApp.Text = "Appanoose";
            this.rBtnApp.UseVisualStyleBackColor = true;
            // 
            // rBtnWapello
            // 
            this.rBtnWapello.AutoSize = true;
            this.rBtnWapello.Location = new System.Drawing.Point(22, 88);
            this.rBtnWapello.Name = "rBtnWapello";
            this.rBtnWapello.Size = new System.Drawing.Size(91, 24);
            this.rBtnWapello.TabIndex = 2;
            this.rBtnWapello.TabStop = true;
            this.rBtnWapello.Text = "Wapello";
            this.rBtnWapello.UseVisualStyleBackColor = true;
            // 
            // rBtnTrustee
            // 
            this.rBtnTrustee.AutoSize = true;
            this.rBtnTrustee.Location = new System.Drawing.Point(22, 58);
            this.rBtnTrustee.Name = "rBtnTrustee";
            this.rBtnTrustee.Size = new System.Drawing.Size(88, 24);
            this.rBtnTrustee.TabIndex = 1;
            this.rBtnTrustee.TabStop = true;
            this.rBtnTrustee.Text = "Trustee";
            this.rBtnTrustee.UseVisualStyleBackColor = true;
            // 
            // rBtnOak
            // 
            this.rBtnOak.AutoSize = true;
            this.rBtnOak.Location = new System.Drawing.Point(22, 28);
            this.rBtnOak.Name = "rBtnOak";
            this.rBtnOak.Size = new System.Drawing.Size(63, 24);
            this.rBtnOak.TabIndex = 0;
            this.rBtnOak.TabStop = true;
            this.rBtnOak.Text = "Oak";
            this.rBtnOak.UseVisualStyleBackColor = true;
            // 
            // grpBoxMeal
            // 
            this.grpBoxMeal.Controls.Add(this.rBtnHigh);
            this.grpBoxMeal.Controls.Add(this.rBtnMed);
            this.grpBoxMeal.Controls.Add(this.rBtnBasic);
            this.grpBoxMeal.Location = new System.Drawing.Point(571, 298);
            this.grpBoxMeal.Name = "grpBoxMeal";
            this.grpBoxMeal.Size = new System.Drawing.Size(147, 124);
            this.grpBoxMeal.TabIndex = 11;
            this.grpBoxMeal.TabStop = false;
            this.grpBoxMeal.Text = "Meal Plan Type: ";
            // 
            // rBtnHigh
            // 
            this.rBtnHigh.AutoSize = true;
            this.rBtnHigh.Location = new System.Drawing.Point(26, 84);
            this.rBtnHigh.Name = "rBtnHigh";
            this.rBtnHigh.Size = new System.Drawing.Size(67, 24);
            this.rBtnHigh.TabIndex = 2;
            this.rBtnHigh.TabStop = true;
            this.rBtnHigh.Text = "High";
            this.rBtnHigh.UseVisualStyleBackColor = true;
            // 
            // rBtnMed
            // 
            this.rBtnMed.AutoSize = true;
            this.rBtnMed.Location = new System.Drawing.Point(26, 55);
            this.rBtnMed.Name = "rBtnMed";
            this.rBtnMed.Size = new System.Drawing.Size(90, 24);
            this.rBtnMed.TabIndex = 1;
            this.rBtnMed.TabStop = true;
            this.rBtnMed.Text = "Medium";
            this.rBtnMed.UseVisualStyleBackColor = true;
            // 
            // rBtnBasic
            // 
            this.rBtnBasic.AutoSize = true;
            this.rBtnBasic.Location = new System.Drawing.Point(26, 25);
            this.rBtnBasic.Name = "rBtnBasic";
            this.rBtnBasic.Size = new System.Drawing.Size(73, 24);
            this.rBtnBasic.TabIndex = 0;
            this.rBtnBasic.TabStop = true;
            this.rBtnBasic.Text = "Basic";
            this.rBtnBasic.UseVisualStyleBackColor = true;
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(247, 353);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(100, 26);
            this.txtID.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(243, 330);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Student ID: ";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(247, 431);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 26);
            this.txtName.TabIndex = 15;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(243, 408);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(120, 20);
            this.lblName.TabIndex = 14;
            this.lblName.Text = "Student Name: ";
            // 
            // rBtnNonDorm
            // 
            this.rBtnNonDorm.AutoSize = true;
            this.rBtnNonDorm.Location = new System.Drawing.Point(376, 338);
            this.rBtnNonDorm.Name = "rBtnNonDorm";
            this.rBtnNonDorm.Size = new System.Drawing.Size(168, 24);
            this.rBtnNonDorm.TabIndex = 16;
            this.rBtnNonDorm.TabStop = true;
            this.rBtnNonDorm.Text = "Non-Dorm Student";
            this.rBtnNonDorm.UseVisualStyleBackColor = true;
            this.rBtnNonDorm.CheckedChanged += new System.EventHandler(this.rBtnNonDorm_CheckedChanged_1);
            // 
            // rBtnDormStud
            // 
            this.rBtnDormStud.AutoSize = true;
            this.rBtnDormStud.Location = new System.Drawing.Point(398, 383);
            this.rBtnDormStud.Name = "rBtnDormStud";
            this.rBtnDormStud.Size = new System.Drawing.Size(134, 24);
            this.rBtnDormStud.TabIndex = 17;
            this.rBtnDormStud.TabStop = true;
            this.rBtnDormStud.Text = "Dorm Student";
            this.rBtnDormStud.UseVisualStyleBackColor = true;
            this.rBtnDormStud.CheckedChanged += new System.EventHandler(this.rBtnDormStud_CheckedChanged_1);
            // 
            // lblMeal
            // 
            this.lblMeal.AutoSize = true;
            this.lblMeal.Location = new System.Drawing.Point(512, 16);
            this.lblMeal.Name = "lblMeal";
            this.lblMeal.Size = new System.Drawing.Size(86, 20);
            this.lblMeal.TabIndex = 21;
            this.lblMeal.Text = "Meal Plan: ";
            // 
            // lblDrm
            // 
            this.lblDrm.AutoSize = true;
            this.lblDrm.Location = new System.Drawing.Point(339, 16);
            this.lblDrm.Name = "lblDrm";
            this.lblDrm.Size = new System.Drawing.Size(121, 20);
            this.lblDrm.TabIndex = 20;
            this.lblDrm.Text = "Dorm Location: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(195, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 20);
            this.label2.TabIndex = 19;
            this.label2.Text = "Student Name: ";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(71, 16);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(95, 20);
            this.lblID.TabIndex = 18;
            this.lblID.Text = "Student ID: ";
            // 
            // ChangeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(773, 526);
            this.Controls.Add(this.lblMeal);
            this.Controls.Add(this.lblDrm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.rBtnNonDorm);
            this.Controls.Add(this.rBtnDormStud);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.grpBoxMeal);
            this.Controls.Add(this.grpBoxDorm);
            this.Controls.Add(this.btnChange);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.lstBoxChange);
            this.Name = "ChangeForm";
            this.Text = "Change Student";
            this.Load += new System.EventHandler(this.ChangeForm_Load);
            this.grpBoxDorm.ResumeLayout(false);
            this.grpBoxDorm.PerformLayout();
            this.grpBoxMeal.ResumeLayout(false);
            this.grpBoxMeal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.ListBox lstBoxChange;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.GroupBox grpBoxDorm;
        private System.Windows.Forms.RadioButton rBtnMahaska;
        private System.Windows.Forms.RadioButton rBtnApp;
        private System.Windows.Forms.RadioButton rBtnWapello;
        private System.Windows.Forms.RadioButton rBtnTrustee;
        private System.Windows.Forms.RadioButton rBtnOak;
        private System.Windows.Forms.GroupBox grpBoxMeal;
        private System.Windows.Forms.RadioButton rBtnHigh;
        private System.Windows.Forms.RadioButton rBtnMed;
        private System.Windows.Forms.RadioButton rBtnBasic;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.RadioButton rBtnNonDorm;
        private System.Windows.Forms.RadioButton rBtnDormStud;
        private System.Windows.Forms.Label lblMeal;
        private System.Windows.Forms.Label lblDrm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblID;
    }
}