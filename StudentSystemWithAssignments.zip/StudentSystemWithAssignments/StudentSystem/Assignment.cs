﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentSystem
{
    [Serializable]
    public class Assignment
    {
        public string name;
        public double ptsEarned;
        public double ptsPoss;

        public string AssignmentName
        {
            get
            {
                return name;
            }
            set
            {
                if (String.IsNullOrEmpty(value))
                {
                    name = "Unknown";
                }
                else
                {
                    name = value;
                }
            }
        }

        public double PointsEarned
        {
            get
            {
                return ptsEarned;
            }
            set
            {
                if (ptsEarned >= 0)
                {
                    ptsEarned = value;
                }
                else
                {
                    ptsEarned = 0;
                }
            }
        }

        public double PointsPossible
        {
            get
            {
                return ptsPoss;
            }
            set
            {
                if (ptsPoss > 0)
                {
                    ptsPoss = value;
                }
                else
                {
                    ptsPoss = 10;
                }
            }
        }

        //default constructor 
        public Assignment() : base()
        {
            name = "Unknown";
            ptsEarned = 0;
            ptsPoss = 10;
        }

        //overloaded constructor 
        public Assignment(string nmm, int pe, double pp) 
        {
            name = nmm;
            ptsEarned = pe;
            ptsPoss = pp;
        }






        //bracket ends class
    }
//bracket ends namespace
}
