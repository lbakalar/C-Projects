﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;
namespace StudentSystem
{
    public partial class MainForm : Form
    {
        public static List<Student> studentList = new List<Student>();

        public MainForm()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            try
            {
                FileStream outFile = new FileStream("studentlist.ser",
                    FileMode.Create, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();

                foreach (var item in studentList)
                {
                    bf.Serialize(outFile, item);
                }
                outFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error writing list to file " + ex.Message);
            }
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddForm af = new AddForm();
            af.Show();
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            ChangeForm cf = new ChangeForm();
            cf.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteForm df = new DeleteForm();
            df.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DisplayForm dpf = new DisplayForm();
            dpf.Show();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists("studentlist.ser"))
                {
                    FileStream inFile = new FileStream("studentlist.ser",
                        FileMode.Open, FileAccess.Read);
                    BinaryFormatter bFormatter = new BinaryFormatter();

                    while (inFile.Position < inFile.Length)
                    {
                        object obj = bFormatter.Deserialize(inFile);
                        if (obj.GetType() == typeof(Student))
                        {
                            MainForm.studentList.Add((Student)obj);
                        }
                        else
                        {
                            MainForm.studentList.Add((DormStudent)obj);
                        }
                    }
                    inFile.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening file, program terminating " + ex.Message);
            }
        }

        private void btnAssign_Click(object sender, EventArgs e)
        {
            AssignmentsForm af = new AssignmentsForm();
            af.Show();
        }
    }
}
