﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CookieSource
{
    [Serializable]
    public class Order : IComparable
    {
        public double orderNum;
        public string custName;
        public double phoneNum;
        public string cookType;
        public int qty;
        public DateTime oDate;
        public DateTime dDate; 
        
        public double OrderNum { get; set; }

        public string CustName
        {
            get
            {
                return custName;
            }
            set
            {
                if (String.IsNullOrEmpty(value))
                {
                    CustNameException nbe =
               new CustNameException();
                    throw (nbe);
                }
                else
                {
                    custName = value;
                }
            }
        }

        public double PhoneNum
        {
            get
            {
                return phoneNum;
            }
            set
            {
                
                if (phoneNum > 0)
                {
                    phoneNum = 6411234567;
                }
                else
                {
                    phoneNum = value;
                }
            }
        }

        public string CookType
        {
            get
            {
                return cookType;
            }
            set
            {
                if (custName == "Chocolate" || custName == "Oatmeal" || custName == "Sugar")
                {
                    custName = value;
                }
                else
                {
                    custName = "Chocolate";
                }
            }
        }

        public int Qty
        {
            get
            {
                return qty;
            }
            set
            {
                if (qty > 0)
                {
                    qty = value;
                }
                else
                {
                    qty = 1;
                }
            }
        }

        public DateTime OrderDate { get; set; }

        public DateTime DeliveryDate { get; set; }

        //default constructor 
        public Order()
        {
            orderNum = 1;
            custName = "Unknown";
            phoneNum = 6411234567;
            cookType = "Chocolate Chip";
            qty = 1;
            oDate = DateTime.Today;
            dDate = DateTime.Today;
        }

        //overloaded constructor 
        public Order(double oNum, string cName, double pNum, string cType, int qtyy, DateTime orderDate, DateTime delvDate )
        {
            orderNum = oNum;
            custName = cName;
            phoneNum = pNum;
            cookType = cType;
            qty = qtyy;
            oDate = DateTime.Today;
            dDate = delvDate;
        }

        public string ToString()
        {
            return "      " + orderNum + "                  " + custName + "           " + phoneNum + "    " + cookType + "         " 
             + qty + "           " + oDate + "   " + dDate;
            
        }

        int IComparable.CompareTo(Object o)
        {
            int returnVal;
            Order date = (Order)o;
            if (this.dDate > date.dDate)
                returnVal = 1;
            else
               if (this.dDate < date.dDate)
                returnVal = -1;
            else
                returnVal = 0;
            return returnVal;
        // bracket ends icomparable
        }
    //bracket ends class 
    }
//bracket ends namespace 
}
