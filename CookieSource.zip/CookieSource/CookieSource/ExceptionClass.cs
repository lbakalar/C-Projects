﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CookieSource
{
    class CustNameException : Exception
    {
        private static string msg = "Customer Name invalid. ";
        public CustNameException() : base(msg)
        {
        }
    }
}
