﻿namespace CookieSource
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCustName = new System.Windows.Forms.Label();
            this.lblPhoneNum = new System.Windows.Forms.Label();
            this.lblQty = new System.Windows.Forms.Label();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.txtPhoneNum = new System.Windows.Forms.TextBox();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.rBtnChoco = new System.Windows.Forms.RadioButton();
            this.rBtnOatmeal = new System.Windows.Forms.RadioButton();
            this.rBtnSugar = new System.Windows.Forms.RadioButton();
            this.lblDelvDate = new System.Windows.Forms.Label();
            this.dtpDelvDate = new System.Windows.Forms.DateTimePicker();
            this.grpBoxTypes = new System.Windows.Forms.GroupBox();
            this.grpBoxTypes.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCustName
            // 
            this.lblCustName.AutoSize = true;
            this.lblCustName.Location = new System.Drawing.Point(22, 30);
            this.lblCustName.Name = "lblCustName";
            this.lblCustName.Size = new System.Drawing.Size(132, 20);
            this.lblCustName.TabIndex = 1;
            this.lblCustName.Text = "Customer Name: ";
            // 
            // lblPhoneNum
            // 
            this.lblPhoneNum.AutoSize = true;
            this.lblPhoneNum.Location = new System.Drawing.Point(31, 86);
            this.lblPhoneNum.Name = "lblPhoneNum";
            this.lblPhoneNum.Size = new System.Drawing.Size(123, 20);
            this.lblPhoneNum.TabIndex = 2;
            this.lblPhoneNum.Text = "Phone Number: ";
            // 
            // lblQty
            // 
            this.lblQty.AutoSize = true;
            this.lblQty.Location = new System.Drawing.Point(78, 135);
            this.lblQty.Name = "lblQty";
            this.lblQty.Size = new System.Drawing.Size(76, 20);
            this.lblQty.TabIndex = 3;
            this.lblQty.Text = "Quantity: ";
            // 
            // txtCustName
            // 
            this.txtCustName.Location = new System.Drawing.Point(160, 27);
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.Size = new System.Drawing.Size(130, 26);
            this.txtCustName.TabIndex = 7;
            // 
            // txtPhoneNum
            // 
            this.txtPhoneNum.Location = new System.Drawing.Point(160, 83);
            this.txtPhoneNum.Name = "txtPhoneNum";
            this.txtPhoneNum.Size = new System.Drawing.Size(130, 26);
            this.txtPhoneNum.TabIndex = 8;
            this.txtPhoneNum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPhoneNum_KeyPress);
            // 
            // txtQty
            // 
            this.txtQty.Location = new System.Drawing.Point(160, 135);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(130, 26);
            this.txtQty.TabIndex = 9;
            this.txtQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQty_KeyPress);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(415, 262);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(85, 35);
            this.btnExit.TabIndex = 15;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(119, 262);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(85, 35);
            this.btnSubmit.TabIndex = 13;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(268, 262);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(85, 35);
            this.btnDisplay.TabIndex = 14;
            this.btnDisplay.Text = "Display ";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // rBtnChoco
            // 
            this.rBtnChoco.AutoSize = true;
            this.rBtnChoco.Location = new System.Drawing.Point(26, 31);
            this.rBtnChoco.Name = "rBtnChoco";
            this.rBtnChoco.Size = new System.Drawing.Size(142, 24);
            this.rBtnChoco.TabIndex = 0;
            this.rBtnChoco.TabStop = true;
            this.rBtnChoco.Text = "Chocolate Chip";
            this.rBtnChoco.UseVisualStyleBackColor = true;
            // 
            // rBtnOatmeal
            // 
            this.rBtnOatmeal.AutoSize = true;
            this.rBtnOatmeal.Location = new System.Drawing.Point(26, 61);
            this.rBtnOatmeal.Name = "rBtnOatmeal";
            this.rBtnOatmeal.Size = new System.Drawing.Size(98, 24);
            this.rBtnOatmeal.TabIndex = 1;
            this.rBtnOatmeal.TabStop = true;
            this.rBtnOatmeal.Text = "Oatmeal ";
            this.rBtnOatmeal.UseVisualStyleBackColor = true;
            // 
            // rBtnSugar
            // 
            this.rBtnSugar.AutoSize = true;
            this.rBtnSugar.Location = new System.Drawing.Point(26, 91);
            this.rBtnSugar.Name = "rBtnSugar";
            this.rBtnSugar.Size = new System.Drawing.Size(77, 24);
            this.rBtnSugar.TabIndex = 2;
            this.rBtnSugar.TabStop = true;
            this.rBtnSugar.Text = "Sugar";
            this.rBtnSugar.UseVisualStyleBackColor = true;
            // 
            // lblDelvDate
            // 
            this.lblDelvDate.AutoSize = true;
            this.lblDelvDate.Location = new System.Drawing.Point(43, 194);
            this.lblDelvDate.Name = "lblDelvDate";
            this.lblDelvDate.Size = new System.Drawing.Size(111, 20);
            this.lblDelvDate.TabIndex = 5;
            this.lblDelvDate.Text = "Delivery Date: ";
            // 
            // dtpDelvDate
            // 
            this.dtpDelvDate.Location = new System.Drawing.Point(160, 193);
            this.dtpDelvDate.MinDate = new System.DateTime(2019, 2, 6, 0, 0, 0, 0);
            this.dtpDelvDate.Name = "dtpDelvDate";
            this.dtpDelvDate.Size = new System.Drawing.Size(275, 26);
            this.dtpDelvDate.TabIndex = 11;
            this.dtpDelvDate.Value = new System.DateTime(2019, 4, 23, 0, 0, 0, 0);
            // 
            // grpBoxTypes
            // 
            this.grpBoxTypes.Controls.Add(this.rBtnOatmeal);
            this.grpBoxTypes.Controls.Add(this.rBtnChoco);
            this.grpBoxTypes.Controls.Add(this.rBtnSugar);
            this.grpBoxTypes.Location = new System.Drawing.Point(376, 27);
            this.grpBoxTypes.Name = "grpBoxTypes";
            this.grpBoxTypes.Size = new System.Drawing.Size(180, 127);
            this.grpBoxTypes.TabIndex = 12;
            this.grpBoxTypes.TabStop = false;
            this.grpBoxTypes.Text = "Types: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(611, 332);
            this.Controls.Add(this.grpBoxTypes);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.txtPhoneNum);
            this.Controls.Add(this.txtCustName);
            this.Controls.Add(this.dtpDelvDate);
            this.Controls.Add(this.lblDelvDate);
            this.Controls.Add(this.lblQty);
            this.Controls.Add(this.lblPhoneNum);
            this.Controls.Add(this.lblCustName);
            this.Name = "Form1";
            this.Text = "The Cookie Source";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.grpBoxTypes.ResumeLayout(false);
            this.grpBoxTypes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblCustName;
        private System.Windows.Forms.Label lblPhoneNum;
        private System.Windows.Forms.Label lblQty;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.TextBox txtPhoneNum;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.RadioButton rBtnChoco;
        private System.Windows.Forms.RadioButton rBtnOatmeal;
        private System.Windows.Forms.RadioButton rBtnSugar;
        private System.Windows.Forms.Label lblDelvDate;
        private System.Windows.Forms.DateTimePicker dtpDelvDate;
        private System.Windows.Forms.GroupBox grpBoxTypes;
    }
}

