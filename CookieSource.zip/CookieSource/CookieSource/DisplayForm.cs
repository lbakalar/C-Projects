﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace CookieSource
{
    public partial class DisplayForm : Form
    {
        public DisplayForm()
        {
            InitializeComponent();
        }

        private void DisplayForm_Load(object sender, EventArgs e)
        {
            lstBoxDisplay.Items.Add("  Order       " + "Customer            " + "Phone            " + "Cookie     " + 
                "Quantity                     " + "Order                                          " + "Delivery");
            lstBoxDisplay.Items.Add("Number      " + "Name                " + "Number              " + "Type " + 
                "                                               " + "Date                                               " + " Date ");
            lstBoxDisplay.Items.Add("");

            int length = Form1.orderList.Count();
            Order[] temp = new Order[length];            
            temp = Form1.orderList.ToArray();
            Array.Sort(temp);
            Order o = new Order();         
            
            for (int i = 0; i < length; i++)
            {
                o = temp[i];
                lstBoxDisplay.Items.Add(o.ToString());
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
