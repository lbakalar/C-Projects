﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;


namespace CookieSource
{
    public partial class Form1 : Form
    {
        public static List<Order> orderList = new List<Order>();
        public double orderNumm = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            DisplayForm df = new DisplayForm();
            df.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {           
            try
            {   
                FileStream outFile = new FileStream("orderlist.ser",
                    FileMode.Create, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();

                foreach (var item in orderList)
                {
                     bf.Serialize(outFile, item);
                 }
                 outFile.Close();
                }
            catch (Exception ex)
            {
                MessageBox.Show("Error writing list to file " + ex.Message);
            }
         this.Close();
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            dtpDelvDate.MinDate = DateTime.Today;
            dtpDelvDate.Value = DateTime.Today;           
            try
            {
                if (File.Exists("orderlist.ser"))
                {
                    FileStream inFile = new FileStream("orderlist.ser",
                        FileMode.Open, FileAccess.Read);
                    BinaryFormatter bFormatter = new BinaryFormatter();

                    while (inFile.Position < inFile.Length)
                    {
                        object obj = bFormatter.Deserialize(inFile);
                        if (obj.GetType() == typeof(Order))
                        {
                            Form1.orderList.Add((Order)obj);
                        }
                        else
                        {

                        }
                    }
                    inFile.Close();
                    Order s = new Order();
                    s = orderList.Last();
                    orderNumm = s.orderNum; 
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening file, program terminating " + ex.Message);
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string type = "";
            orderNumm += 1;

            if (rBtnChoco.Checked){
                type = "Chocolate Chip";
            }
            if (rBtnOatmeal.Checked)
            {
                type = "Oatmeal";
            }
            if (rBtnSugar.Checked)
            {
                type = "Sugar";
            }            

            if (String.IsNullOrEmpty(txtPhoneNum.Text))
            {
                MessageBox.Show("Phone number required. ");
            }

            try
            {
                Order o = new Order(orderNumm,
                              txtCustName.Text,
                              Convert.ToDouble(txtPhoneNum.Text),
                              type,
                              Convert.ToInt32(txtQty.Text),
                              DateTime.Today,
                              dtpDelvDate.Value
                              );
                orderList.Add(o);
                txtCustName.Focus();
            }
            catch 
            {
                MessageBox.Show("Error, please re-check all data ");
            }
        }

        private void txtPhoneNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') &&
                (e.KeyChar != (char)Keys.Back))
            {
                e.Handled = true;
            }
        }

        private void txtQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') &&
                (e.KeyChar != (char)Keys.Back))
            {
                e.Handled = true;
            }
        }
    }
}
