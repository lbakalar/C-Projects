﻿using System;
using System.IO;
using static System.Console;

namespace HaroldsHomeService
{
    class DemoJobs
    {
        public static Job[] arrJobs = new Job[5];
        public static int jIndex = 0;
        private static bool inputSwitch = true;
        static void Main(string[] args)
        {
            string jb="";
            double hr=0;
            double rt=0;

            //calling input(menu)
            input(jb, hr, rt);

        //bracket ends main 
        }        

        private static void input(string jb, double hr, double rt)
        {
            String choice;
            Write("Enter 1 to enter jobs \n");
            Write("Enter 2 to display all jobs \n");
            Write("Enter anything else to exit \n");
            choice = ReadLine();

            if (choice == "1" || choice == "2")
            {
                if (choice == "1")
                {
                    if (inputSwitch == true)
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            jb = PromptJobs();
                            hr = PromptHours(out double hours);
                            rt = PromptRates(out double rates);
                            MakeArray(jb, hr, rt);
                        }
                        Console.Clear();

                        inputSwitch = false;

                        //calling input(menu)
                        input(jb, hr, rt);                  
                    }
                    else
                    {
                        WriteLine("Error all jobs have been entered");
                        ReadLine();
                        Console.Clear();

                        //calling input(menu)
                        input(jb, hr, rt);
                    }
                }
                else
                {
                    //if choice = 2	
                    Console.Clear();

                    //calling output
                    output();

                    Console.Clear();

                    //calling input
                    input(jb, hr, rt);
                }
            }
            else
            {
                Write("Program ending");
                ReadLine();
            }
        //bracket ends input
        }

        private static string PromptJobs()
        {
            string input;
            bool ok = true;
            string job = null;
            do
            {
                Write("\nEnter job: ");
                input = ReadLine();
                if (!String.IsNullOrEmpty(input))
                {
                    job = input;
                    ok = true;
                }
                else
                {
                    WriteLine("Invalid job");
                    ok = false;
                }  
            } while (!ok);
            return job;
        //bracket ends prompt jobs 
        }

        private static double PromptHours(out double hours)
        {
            string input;
            bool ok = true;
            hours = 0;
            do
            {
                try
                {
                    Write("Enter number of hours: ");
                    input = ReadLine();
                    hours = Convert.ToDouble(input);
                    ok = true;
                }
                catch (Exception)
                {
                    WriteLine("Invalid hours");
                    ok = false;
                }
            } while (!ok);
            return hours;                       
        //bracket ends prompt hours 
        }

        private static double PromptRates(out double rates)
        {
            string input;
            bool ok = true;
            rates = 0;
            do
            {
                try
                {
                    Write("Enter rate: ");
                    input = ReadLine();
                    rates = Convert.ToDouble(input);
                    ok = true;
                }
                catch (Exception)
                {
                    WriteLine("Invalid rate");
                    ok = false;
                }
            } while (!ok);
            return rates;
        //bracket ends prompt rate 
        }

        private static void MakeArray(string js, double hourr, double ratee)
        {
            Job j = new Job();
            j.JobDesc = js;
            j.Hours = hourr;
            j.Rate = ratee;
            arrJobs[jIndex] = j;
            jIndex++;
        //backet ends make array    
        }
                
        private static void output()
        {
            for (int i = 0; i < 5; i++)
            {
                WriteLine("Job Desc: " + arrJobs[i].JobDesc);
                WriteLine("Hours: " + arrJobs[i].Hours);
                WriteLine("Rate: " + arrJobs[i].Rate);
                WriteLine("Total: " + arrJobs[i].Calcs() + "\n");
            }
            ReadLine();

        //bracket ends output
        }   
    //bracket ends class
    }
//bracket ends namespace
}
