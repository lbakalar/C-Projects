﻿/*Libby Bakalar 
* this application allows jobs to be entered, 
* stored in an array, and displayed
*/

namespace HaroldsHomeService
{
    class Job
    {
        public string JobDesc { get; set; }
        public double Hours { get; set; }
        public double Rate { get; set; }

        //default constructor 
        public Job()
        {
            JobDesc = "Mow Yard";
            Hours = 1;
            Rate = 10.00;
        }

        //first overloaded constructor
        public Job(string j)
        {
            JobDesc = j;
            Hours = 1;
            Rate = 10.00;
        }

        //second overloaded constructor
        public Job(string j, double h, double r)
        {
            JobDesc = j;
            Hours = h;
            Rate = r;
        }

        public double Calcs()
        {
            return Hours * Rate;
        }

    //bracket ends class
    }
//bracket ends namespace
}
