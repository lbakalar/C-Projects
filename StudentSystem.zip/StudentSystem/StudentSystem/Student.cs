﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentSystem
{
    [Serializable]
    public class Student : IComparable
    {
        public int studID;
        public string studName;

        public int ID
        {
            get
            {
                return studID;
            }
            set
            {
                if (studID > 0)
                {
                    studID = value;
                }
                else
                {
                    studID = 12345;
                }
            }
        }

        public string StudName
        {
            get
            {
                return studName;
            }
            set
            {
                if (String.IsNullOrEmpty(value))
                {
                    studName = "Unknown";
                }
                else
                {
                    studName = value;
                }
            }
        }

        //default constructor 
        public Student()
        {
            studID = 12345;
            studName = "Unknown";
        }

        //overloaded constructor 
        public Student(int id, string nm)
        {
            studID = id;
            studName = nm;
        }

        public override string ToString()
        {
            return "     " + studID + "                      " + studName;
        }

        int IComparable.CompareTo(Object o)
        {
            int returnVal;
            Student id = (Student)o;
            if (this.studID > id.studID)
                returnVal = 1;
            else
               if (this.studID < id.studID)
                returnVal = -1;
            else
                returnVal = 0;
            return returnVal;
        // bracket ends icomparable
        }
    //bracket ends class
    }
//bracket ends namespace
}
