﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;

namespace StudentSystem
{
    public partial class AddForm : Form
    {
        public AddForm()
        {
            InitializeComponent();
        }

        private void AddForm_Load(object sender, EventArgs e)
        {
            grpBoxDorm.Visible = false;
            grpBoxMeal.Visible = false;
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string dorm = "";
            string meal = "";
            if (rBtnOak.Checked)
            {
                dorm = "Oak";
            }
            if (rBtnTrustee.Checked)
            {
                dorm = "Trustee";
            }
            if (rBtnWapello.Checked)
            {
                dorm = "Wapello";
            }
            if (rBtnApp.Checked)
            {
                dorm = "Appanoose";
            }
            if (rBtnMahaska.Checked)
            {
                dorm = "Mahaska";
            }
            if (rBtnBasic.Checked)
            {
                meal = "Basic";
            }
            if (rBtnMed.Checked)
            {
                meal = "Medium";
            }
            if (rBtnHigh.Checked)
            {
                meal = "High";
            }
            
            try
            {
                if (rBtnDormStud.Checked)
                {
                    DormStudent s = new DormStudent(Convert.ToInt32(txtID.Text),
                              txtName.Text,
                              dorm,
                              meal
                              );
                    MainForm.studentList.Add(s);
                    txtID.Focus();
                }
                if (rBtnNonDorm.Checked)
                {
                    Student s = new Student(Convert.ToInt32(txtID.Text),
                              txtName.Text);
                    MainForm.studentList.Add(s);
                    txtID.Focus();
                }                
            }
            catch
            {
                MessageBox.Show("Error, please re-check all data ");
            }
        }

        private void txtID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') &&
                (e.KeyChar != (char)Keys.Back))
            {
                e.Handled = true;
            }
        }

        public void rBtnDormStud_CheckedChanged(object sender, EventArgs e)
        {
            grpBoxDorm.Visible=true;
            grpBoxMeal.Visible = true;
        }

        public void rBtnNonDorm_CheckedChanged(object sender, EventArgs e)
        {
            grpBoxDorm.Visible = false;
            grpBoxMeal.Visible = false;
        }
    }
}
