﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentSystem
{
    public partial class ChangeForm : Form
    {
        public ChangeForm()
        {
            InitializeComponent();
        }

        private void ChangeForm_Load(object sender, EventArgs e)
        {
            foreach (var item in MainForm.studentList)
            {
                if (item is DormStudent)
                {
                    DormStudent ds = new DormStudent();
                    ds = (DormStudent)item;
                    item.ToString();
                    lstBoxChange.Items.Add(item);
                }
                else
                {
                    Student s = new Student();
                    s = (Student)item;
                    s.ToString();
                    lstBoxChange.Items.Add(item);
                }
            }
            grpBoxDorm.Visible = false;
            grpBoxMeal.Visible = false;
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            string dorm = "";
            string meal = "";
            if (rBtnOak.Checked)
            {
                dorm = "Oak";
            }
            if (rBtnTrustee.Checked)
            {
                dorm = "Trustee";
            }
            if (rBtnWapello.Checked)
            {
                dorm = "Wapello";
            }
            if (rBtnApp.Checked)
            {
                dorm = "Appanoose";
            }
            if (rBtnMahaska.Checked)
            {
                dorm = "Mahaska";
            }
            if (rBtnBasic.Checked)
            {
                meal = "Basic";
            }
            if (rBtnMed.Checked)
            {
                meal = "Medium";
            }
            if (rBtnHigh.Checked)
            {
                meal = "High";
            }
            
            try
            {
                if (rBtnDormStud.Checked)
                {
                     MainForm.studentList[lstBoxChange.SelectedIndex] = new DormStudent(Convert.ToInt32(txtID.Text),
                              txtName.Text,
                              dorm,
                              meal
                              );
                    txtID.Focus();
                }
                if (rBtnNonDorm.Checked)
                {
                    MainForm.studentList[lstBoxChange.SelectedIndex] = new Student(Convert.ToInt32(txtID.Text),
                              txtName.Text);
                    txtID.Focus();
                }                
            }
            catch
            {
                MessageBox.Show("Error, please re-check all data ");
            }

            lstBoxChange.Items.Clear();

            foreach (var item in MainForm.studentList)
            {
                if (item is DormStudent)
                {
                    DormStudent ds = new DormStudent();
                    ds = (DormStudent)item;
                    item.ToString();
                    lstBoxChange.Items.Add(item);
                }
                else
                {
                    Student s = new Student();
                    s = (Student)item;
                    s.ToString();
                    lstBoxChange.Items.Add(item);
                }
            }




        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }        
        
        private void rBtnNonDorm_CheckedChanged_1(object sender, EventArgs e)
        {
            grpBoxDorm.Visible = false;
            grpBoxMeal.Visible = false;
        }

        private void rBtnDormStud_CheckedChanged_1(object sender, EventArgs e)
        {
            grpBoxDorm.Visible = true;
            grpBoxMeal.Visible = true;
        }
    }
}
