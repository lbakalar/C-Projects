﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentSystem
{
    public partial class DisplayForm : Form
    {
        public DisplayForm()
        {
            InitializeComponent();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DisplayForm_Load(object sender, EventArgs e)
        {
            List<Student> temp = new List<Student>();
            temp = MainForm.studentList;
            temp.Sort();

            foreach (var item in temp)
            {
                if (item is DormStudent)
                {
                    DormStudent ds = new DormStudent();
                    ds = (DormStudent)item;
                    item.ToString();
                    lstBoxDisplay.Items.Add(item);
                }
                else
                {
                    Student s = new Student();
                    s = (Student)item;
                    item.ToString();
                    lstBoxDisplay.Items.Add(item);
                }
            }
        }
    }
}
