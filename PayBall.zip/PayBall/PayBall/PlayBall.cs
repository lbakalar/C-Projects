﻿using System;
using System.IO;
using static System.Console;

namespace PlayBall
{
    class PlayBall
    {
        static int[,] arrPlayer = new int[12, 2];

        static void Main(string[] args)
        {
            string[] names = new string[12];
            int playNum = 0;
            int bts = 0;
            int hts = 0;

            //calling init
            init(names);

            //calling input(menu)
            input(names, playNum, bts, hts);
            
        //bracket ends main 
        }

        private static void input(string[] names, int playNum, int bts, int hts)
        {
            String choice;
            String again = "Y";

            Write("Enter 1 to enter player data \n");
            Write("Enter 2 to Display Summary \n");
            Write("Enter anything else to exit \n");
            choice = ReadLine();

            if (choice == "1" || choice == "2")
            {
                if (choice == "1")
                {
                    do
                    {
                        playNum = promptplayerNum(out int playerNum);
                        bts = promptBats(out int bats);
                        hts = promptHits(out int hits, bats);
                        calcs(names, playNum, bts, hts);
                        Write("Enter again? (Y or N): ");
                        again = ReadLine();

                    } while (again.ToUpper() == "Y"); 
                    {
                        Console.Clear();
                        //calling input(menu)
                        input(names, playNum, hts, bts);
                    }
                }
                else
                {
                    //if choice = 2	
                    Console.Clear();

                    //calling output
                    output(names, playNum, hts, bts);

                    Console.Clear();

                    //calling input
                    input(names, playNum, hts, bts);
                }
            }
            else
            {
                Write("Program ending");
                ReadLine();
            }

        //bracket ends input
        }

        private static string[] init(string[] arrOfNames)
        {
            FileStream fsNames = new FileStream("names.dat", FileMode.Open, FileAccess.Read);
            StreamReader srNames = new StreamReader(fsNames);
            string record;
            int row = 0;

            record = srNames.ReadLine();

            while (record != null)
            {
                arrOfNames[row] = record;
                row++;
                record = srNames.ReadLine();
            }
            
            //initializing player table
            for (int r = 0; r < 12; r++)
            {
                for (int c = 0; c < 2; c++)
                {
                    arrPlayer[r,c] = 0;
                }
            }            
            return arrOfNames;

        //bracket ends init
        }

        private static int promptplayerNum(out int playerNum)
        {
            string input;
            bool ok = true;
            playerNum = 0;
            do
            {
                try
                {
                    Write("Enter player number  ");
                    input = ReadLine();
                    playerNum = Convert.ToInt32(input);
                    ok = true;
                    if (playerNum < 1 || playerNum > 12)
                    {
                        WriteLine("Player number must be 1-12, defaulted to 1");
                        playerNum = 1;
                        ok = false;
                    }
                }
                catch (Exception)
                {
                    WriteLine("Player number must be 1-12, defaulted to 1");
                    ok = false;
                }
            } while (!ok);
            return playerNum;

        //bracket ends prompt player number
        }

        private static int promptBats(out int bats)
        {
            string input;
            bool ok = true;
            bats = 0;
            do
            {
                try
                {
                    Write("Enter number of at bats ");
                    input = ReadLine();
                    bats = Convert.ToInt32(input);
                    ok = true;
                }
                catch (Exception)
                {
                    WriteLine("Invalid at bats");
                    ok = false;
                }
            } while (!ok);
            return bats;

        //bracket ends prompt bats
        }

        private static int promptHits(out int hits, int bats)
        {
            string input;
            bool ok = true;
            hits = 0;
            do
            {
                try
                {
                    Write("Enter number of hits ");
                    input = ReadLine();
                    hits = Convert.ToInt32(input);
                    ok = true;
                    if (hits > bats)
                    {
                        WriteLine("Hits cannot be greater than bats");
                        ok = false;
                    }
                }
                catch (Exception)
                {
                    WriteLine("Invalid hits");
                    ok = false;
                }
            } while (!ok);
            return hits;

        //bracket ends prompt hits
        }

        private static void calcs(string[] names, int plNum, int b, int h)
        {            
            //adding input bats to player table
            arrPlayer[plNum-1, 1] += b;

            //adding input hits to player table
            arrPlayer[plNum-1, 0] += h;
                        
        //bracket ends calcs
        }

        private static void output(string[] arrOfNames, int plNum, int b, int h)
        {
            double Average = 0;            
            for (int r = 0; r < arrOfNames.Length; r++)
            {

                if (arrPlayer[r, 1] > 0)
                {
                    Average = (double)arrPlayer[r, 0] / arrPlayer[r, 1];
                }
                else
                {
                    Average = 0;
                }

                WriteLine("Player Name: " +  arrOfNames[r] + "   At Bats: " + arrPlayer[r, 1] + 
                "   Hits: " + arrPlayer[r, 0] + "   Average: " + Average.ToString("f3") + "\n");                 
            }
            ReadLine();

        //bracket ends output
        }

    //bracket ends class
    }

//bracket ends namespace
}
