﻿using static System.Console;

namespace HaroldsHomeService
{
    class DemoJobsTest
    {
        public static void Main(string[] args)
        {
            //tests default and both overload constructors 
            Job j = new Job();
            Job o = new Job("Gardener");
            Job b = new Job("Mechanic", 10, 20);

            //prints out jobs
            WriteLine(j.ToString() + "\n");
            WriteLine(o.ToString() + "\n");
            WriteLine(b.ToString() + "\n");
            ReadLine();

            //bracket ends main 
        }
        //bracket ends class
    }
    //bracket ends namespace
}
