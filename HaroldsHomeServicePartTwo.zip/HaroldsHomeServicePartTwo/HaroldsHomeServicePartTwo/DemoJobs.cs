﻿/*Libby Bakalar 
* April 10, 2019 
* this application asks the user to enter 5 jobs (description, hours, and rate)
* displays them back according to total(hours* rate) and also gives them 
* the option to combine to jobs together
*/

using System;
using System.IO;
using static System.Console;

namespace HaroldsHomeService
{
    class DemoJobs
    {
        public static Job[] arrJobs = new Job[5];
        public static int jIndex = 0;
        private static bool inputSwitch = true;
        static void Main(string[] args)
        {
            string jb = "";
            double hr = 0;
            double rt = 0;
            Job job = new Job();

            //calling input(menu)
            input(jb, hr, rt, job);

        //bracket ends main 
        }

        private static void input(string jb, double hr, double rt, Job job)
        {
            String choice;
            Write("Enter 1 to enter jobs \n");
            Write("Enter 2 to display all jobs \n");
            Write("Enter 3 to combine two jobs \n");
            Write("Enter anything else to exit \n");
            choice = ReadLine();

            if (choice == "1" || choice == "2")
            {
                if (choice == "1")
                //entering jobs
                {
                    if (inputSwitch == true)
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            jb = PromptJobs();
                            hr = PromptHours(out double hours);
                            rt = PromptRates(out double rates);
                            MakeArray(jb, hr, rt);
                        }
                        Console.Clear();
                        inputSwitch = false;
                        //calling input(menu)
                        input(jb, hr, rt, job);
                    }
                    else
                    {
                        WriteLine("Error all jobs have been entered");
                        ReadLine();
                        Console.Clear();

                        //calling input(menu)
                        input(jb, hr, rt, job);
                    }
                }
                else
                //if choice = 2 (displaying jobs)
                {
                    if (inputSwitch == false)
                    {
                        Console.Clear();
                        //calling output
                        output();
                        Console.Clear();
                        //calling input
                        input(jb, hr, rt, job);
                    }
                    else
                    {
                        WriteLine("Error, not all jobs have been entered");
                        ReadLine();
                        Console.Clear();
                        //calling input(menu)
                        input(jb, hr, rt ,job);
                    }
                }
            }
            else
            {
                if (choice == "3")
                //combining two jobs
                {
                    if (inputSwitch == false)
                    {
                        Console.Clear();
                        job = CombineJobs();
                        WriteLine("The new job is \"{0}\"", job.JobDesc);
                        WriteLine("It has {0} hours and a rate of {1}",
                           job.Hours, job.Rate.ToString("C"));
                        ReadLine();
                        Console.Clear();
                        //calling input(menu)
                        input(jb, hr, rt, job);
                    }
                    else
                    {
                        WriteLine("Error, not all jobs have been entered");
                        ReadLine();
                        Console.Clear();
                        //calling input(menu)
                        input(jb, hr, rt, job);
                    }
                }
                else
                {
                    Write("Program ending");
                    ReadLine();
                }
            }
        //bracket ends input
        }

        private static Job CombineJobs()
        {
            String jobOne;
            String jobTwo;
            Job job1 = new Job();
            Job job2 = new Job();
            Job newJob;
            int index1 = 0;
            int index2 = 0;
            bool errSw = false;
            do
            {
                WriteLine("What is the first job you would like to use to combine? (1-5)");
                jobOne = ReadLine();
                try
                {
                    index1 = Int32.Parse(jobOne);
                    job1 = arrJobs[index1 - 1];
                    errSw = true;
                }
                catch
                {
                    WriteLine("Error, invalid job number");
                    errSw = false;
                }
            } while (!errSw);

            do
            {
                WriteLine("What is the second job you would like to use to combine? (1-5)");
                jobTwo = ReadLine(); 
                try
                {
                    index2 = Int32.Parse(jobTwo);
                    job2 = arrJobs[index2 - 1];
                    errSw = true;
                }
                catch
                {
                    WriteLine("Error, invalid job number");
                    errSw = false;
                }
            } while (!errSw);

            newJob = job1 + job2;

            return newJob;
        //bracket ends combine jobs
        }

        private static string PromptJobs()
        {
            string input;
            bool ok = true;
            string job = null;
            do
            {
                Write("\nEnter job: ");
                input = ReadLine();
                if (!String.IsNullOrEmpty(input))
                {
                    job = input;
                    ok = true;
                }
                else
                {
                    WriteLine("Invalid job");
                    ok = false;
                }
            } while (!ok);
            return job;
        //bracket ends prompt jobs 
        }

        private static double PromptHours(out double hours)
        {
            string input;
            bool ok = true;
            hours = 0;
            do
            {
                try
                {
                    Write("Enter number of hours: ");
                    input = ReadLine();
                    hours = Convert.ToDouble(input);
                    ok = true;
                }
                catch (Exception)
                {
                    WriteLine("Invalid hours");
                    ok = false;
                }
            } while (!ok);
            return hours;
        //bracket ends prompt hours 
        }

        private static double PromptRates(out double rates)
        {
            string input;
            bool ok = true;
            rates = 0;
            do
            {
                try
                {
                    Write("Enter rate: ");
                    input = ReadLine();
                    rates = Convert.ToDouble(input);
                    ok = true;
                }
                catch (Exception)
                {
                    WriteLine("Invalid rate");
                    ok = false;
                }
            } while (!ok);
            return rates;
        //bracket ends prompt rate 
        }

        private static void MakeArray(string js, double hourr, double ratee)
        {
            Job j = new Job();
            j.JobDesc = js;
            j.Hours = hourr;
            j.Rate = ratee;
            arrJobs[jIndex] = j;
            jIndex++;
        //backet ends make array    
        }

        private static void output()
        {
            int x;
            Array.Sort(arrJobs);
            for (x = 0; x < arrJobs.Length; ++x)
                WriteLine("{0} {1} {2} {3} {4} {5} {6} {7}", "Job Descprition: ", arrJobs[x].JobDesc, 
                    " Hours: ", arrJobs[x].Hours, " Rate: ", arrJobs[x].Rate, "Total: ", arrJobs[x].Calcs(), "\n");
            ReadLine();
        //bracket ends output
        }
    //bracket ends class
    }
 //bracket ends namespace
}
