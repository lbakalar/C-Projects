﻿/*Libby Bakalar 
 * April 10, 2019 
* this application allows jobs, hours, and rates to be entered, 
* stored in an arrays, and displayed based on total(rate * hours)
*/

using System;

namespace HaroldsHomeService
{
    class Job : IComparable
    {
        public string JobDesc { get; set; }
        public double Hours { get; set; }
        public double Rate { get; set; }

        public static Job operator +(Job one, Job two)
        {
            string newDesc = one.JobDesc + " and " + two.JobDesc;

            double newHours = one.Hours + two.Hours;

            double number = one.Rate + two.Rate;
            double newRate = number / 2;

            return (new Job(newDesc, newHours, newRate));
        }

        //default constructor 
        public Job()
        {
            JobDesc = "Mow Yard";
            Hours = 1;
            Rate = 10.00;
        }

        //first overloaded constructor
        public Job(string j)
        {
            JobDesc = j;
            Hours = 1;
            Rate = 10.00;
        }

        //second overloaded constructor
        public Job(string j, double h, double r)
        {
            JobDesc = j;
            Hours = h;
            Rate = r;
        }

        public double Calcs()
        {
            return Hours * Rate;
        }    

        int IComparable.CompareTo(Object o)
        {
            int returnVal;
            Job job = (Job)o;
            if (this.Calcs() > job.Calcs())
                returnVal = 1;
            else
               if (this.Rate < job.Rate)
                returnVal = -1;
            else
                returnVal = 0;
            return returnVal;
        //bracket ends icomparable 
        }
    //bracket ends class
    }       
//bracket ends namespace
}

